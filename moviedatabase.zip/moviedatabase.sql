
DROP DATABASE IF EXISTS `movie database`;
CREATE DATABASE `movie database` DEFAULT CHARACTER SET=utf8;
USE `movie database`;

CREATE TABLE `MOVIE`(
  `NAME` Varchar(200) NOT NULL,
  `RATING` Varchar(50) NOT NULL,
  `PLAYTIME` INT NOT NULL,
  `RELEASE_DATE` Date NOT NULL,
  `DETAILS` TEXT
) ;
ALTER TABLE `MOVIE` ADD `MOVIE_ID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY;

CREATE TABLE `TV_SHOW`(
  `TV_SHOW_NAME`  Varchar(200) NOT NULL,
  `RATING` Varchar(50) NOT NULL,  
  `PLAYTIME` INT NOT NULL, 
  `RELEASE_DATE` Date NOT NULL,
  `DESCRIPTION` TEXT,
  `EPISODES` INT NOT NULL
);

ALTER TABLE `TV_SHOW` ADD `TV_SHOW_ID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY;

CREATE TABLE `USERACCOUNT`(
  `PERSON_NAME` Varchar(50) NOT NULL,
  `GENDER` Char(1) NOT NULL,
  `USERNAME` Varchar(50) NOT NULL,
  `HOURSWATCHED` INT NOT NULL
);
ALTER TABLE `USERACCOUNT` ADD `USER_ID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY;


INSERT INTO MOVIE
           (`NAME`
           ,`RATING`
           ,`PLAYTIME`
           ,`RELEASE_DATE`
           ,`DETAILS`)
     VALUES
           ('The Godfather','R'
           ,'175'
           ,'1972-03-24'
           ,'The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.');

INSERT INTO MOVIE
           (`NAME`
           ,`RATING`
           ,`PLAYTIME`
           ,`RELEASE_DATE`
           ,`DETAILS`)
     VALUES
           ('The Dark Night','PG-13'
           ,'152'
           ,'2008-07-18'
           ,'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, the caped crusader must come to terms with one of the greatest psychological tests of his ability to fight injustice.');


INSERT INTO MOVIE
           (`NAME`
           ,`RATING`
           ,`PLAYTIME`
           ,`RELEASE_DATE`
           ,`DETAILS`)
     VALUES
           ('The Shawshank Redemption','R'
           ,'142'
           ,'1994-10-14'
           ,'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.');

INSERT INTO MOVIE
           (`NAME`
           ,`RATING`
           ,`PLAYTIME`
           ,`RELEASE_DATE`
           ,`DETAILS`)
     VALUES
           ('Inception','PG-13'
           ,'148'
           ,'2010-07-16'
           ,'A thief, who steals corporate secrets through use of dream-sharing technology, is given the inverse task of planting an idea into the mind of a CEO.');


INSERT INTO MOVIE
           (`NAME`
           ,`RATING`
           ,`PLAYTIME`
           ,`RELEASE_DATE`
           ,`DETAILS`)
     VALUES
           ('The Silence of the Lambs','R'
           ,'118'
           ,'1991-02-14'
           ,'A young F.B.I. cadet must confide in an incarcerated and manipulative killer to receive his help on catching another serial killer who skins his victims.');
           
INSERT INTO TV_SHOW
            (`TV_SHOW_NAME`,
            `RATING`, 
			`PLAYTIME`,
            `RELEASE_DATE`,
            `DESCRIPTION`,
            `EPISODES`)
     VALUES
           ('Planet Earth II','TV-G'
           ,'51'
           ,'2017-02-18'
           ,'David Attenborough returns in this breathtaking documentary showcasing life on Planet Earth.', 6);

INSERT INTO TV_SHOW
            (`TV_SHOW_NAME`,
            `RATING`, 
			`PLAYTIME`,
            `RELEASE_DATE`,
            `DESCRIPTION`,
            `EPISODES`)
     VALUES
           ('Avatar: The Last Airbender','TV-Y7-FV'
           ,'23'
           ,'2006-09-19'
           ,'In a war-torn world of elemental magic, a young boy reawakens to undertake a dangerous mystic quest to fulfill his destiny as the Avatar, and bring peace to the world.', 65);


INSERT INTO TV_SHOW
            (`TV_SHOW_NAME`,
            `RATING`, 
			`PLAYTIME`,
            `RELEASE_DATE`,
            `DESCRIPTION`,
            `EPISODES`)
     VALUES
           ('Cowboy Bebop','TV-MA'
           ,'24'
           ,'2001-09-02'
           ,'The futuristic misadventures and tragedies of an easygoing bounty hunter and his partners.', 26);

INSERT INTO TV_SHOW
            (`TV_SHOW_NAME`,
            `RATING`, 
			`PLAYTIME`,
            `RELEASE_DATE`,
            `DESCRIPTION`,
            `EPISODES`)
     VALUES
           ('Friends ','TV-14'
           ,'148'
           ,'1994-09-22'
           ,'Follows the personal and professional lives of six twenty to thirty-something-year-old friends living in Manhattan.', 236);


INSERT INTO TV_SHOW
            (`TV_SHOW_NAME`,
            `RATING`, 
			`PLAYTIME`,
            `RELEASE_DATE`,
            `DESCRIPTION`,
            `EPISODES`)
     VALUES
           ('The Simpsons','R'
           ,'22'
           ,'1989-12-17'
           ,'The satiric adventures of a working-class family in the misfit city of Springfield.', 663);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Tim',  'M', 'bigtim2000', 10);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Kate', 'F', 'katexoxo', 97);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Violet', 'F', 'littleflower16', 67);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Frank',  'M', 'oldguy89', 2);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Nathan', 'M', 'skateboarddude4', 8);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Drake', 'M', 'guitardude2', 45);

INSERT INTO USERACCOUNT(PERSON_NAME,GENDER,USERNAME, HOURSWATCHED) 
VALUES
('Troy', 'M', 'Troy123', 32);



